import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import { env } from './src/config/env.js';
import authRoutes from './src/routes/authRoutes.js';
import incidentRoutes from './src/routes/incidentRoutes.js';
import resourceRoutes from './src/routes/resourceRoutes.js';
import allocationRoutes from './src/routes/allocationRoutes.js';
import dashboardRoutes from './src/routes/dashboardRoutes.js';
import syncRoutes from './src/routes/syncRoutes.js';

export const app = express();

app.use(helmet());
app.use(cors({
  origin: env.FRONTEND_URL,
  credentials: true
}));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

const limiter = rateLimit({
  windowMs: parseInt(env.RATE_LIMIT_WINDOW_MS),
  max: parseInt(env.RATE_LIMIT_MAX),
  message: { success: false, message: 'Too many requests, please try again later.' }
});
app.use(limiter);

// Routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/incidents', incidentRoutes);
app.use('/api/v1/resources', resourceRoutes);
app.use('/api/v1/allocations', allocationRoutes);
app.use('/api/v1/dashboard', dashboardRoutes);
app.use('/api/v1/sync', syncRoutes);

// Health check
app.get('/api/v1/health', (req, res) => {
  res.status(200).json({ success: true, data: { status: 'ok', timestamp: new Date() } });
});

app.use((req, res, next) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ success: false, message: err.message || 'Internal Server Error' });
});
