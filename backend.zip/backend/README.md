# ResQ Backend

This is the Node.js/Express/MongoDB backend for the ResQ Disaster Response Platform.

## Requirements
- Node.js v18+
- MongoDB v5+

## Setup

1. Install dependencies:
   ```bash
   cd backend
   npm install
   ```

2. Configure environment:
   Copy `.env.example` to `.env` and adjust variables as needed.
   ```bash
   cp .env.example .env
   ```

3. Seed the database (creates test users and data):
   ```bash
   node seed.js
   ```

4. Run the server:
   ```bash
   npm run dev
   # or
   node server.js
   ```

## Test Accounts

The seeder creates two accounts (password for both is `password123`):
- `admin@resq.local` (Role: Admin)
- `operator@resq.local` (Role: Operator)

## Architecture Notes

- **Authentication**: JWT based. Short-lived Access Token returned in payload, long-lived Refresh Token stored in HTTP-Only secure cookie.
- **Concurrency**: Allocation engine uses Optimistic Concurrency Control (`findOneAndUpdate` with `$gte` conditionals) to prevent race conditions during deployments.
- **Offline Sync**: The `/api/v1/sync/batch` endpoint accepts an array of UUID-tagged operations. It guarantees idempotency (prevents double-applying if a request is retried) and resolves timestamp conflicts.
- **Duplicate Detection**: The incident creation pipeline calculates geospatial Haversine distances and Jaccard text similarity to flag possible duplicate incidents automatically.
